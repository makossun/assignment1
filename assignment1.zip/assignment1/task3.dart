import 'dart:io';

void main() {
  print('Enter a number:');
  int number = int.tryParse(readLine()) ?? 0;

  if (number > 0) {
    print('Number is positive.');
  } else if (number < 0) {
    print('Number is negative.');
  } else {
    print('Number is neither positive nor negative.');
  }
}

String readLine() {
  return stdin.readLineSync() ?? '';
}
