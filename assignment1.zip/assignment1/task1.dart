import 'dart:io';

void main() {
  print('what is your name:');
  String name = readLine();

  print('$name. What is your surname:');
  String surname = readLine();

  print('$name $surname. Enter your faculty:');
  String faculty = readLine();

  print('Nice to meet you at $faculty faculty, Dr. $name $surname.');
}

String readLine() {
  return stdin.readLineSync() ?? '';
}
