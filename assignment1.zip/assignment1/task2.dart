import 'dart:io';

void main() {
  print('Enter your name:');
  String name = readLine();

  print('$name. Enter your surname:');
  String surname = readLine();

  print('$name $surname. Enter your year of birth:');
  int birthYear = int.tryParse(readLine()) ?? 0;

  int currentYear = DateTime.now().year;
  int age = currentYear - birthYear;

  print('Dear $name $surname, you are $age years old.');
}

String readLine() {
  return stdin.readLineSync() ?? '';
}
