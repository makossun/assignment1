# Dart Console Applications

## 1. Personalized Greeting

### Description

This Dart console application prompts the user to enter their name, surname, and faculty. After receiving the inputs, it prints a personalized greeting message including the user's name, surname, and faculty.

### How to Run

1. Make sure you have Dart installed on your system.
2. Open a terminal or command prompt.
3. Navigate to the directory containing the Dart file.
4. Run the program using the command: `dart filename.dart`
5. Follow the prompts to enter your information.

## 2. Age Calculator

### Description

This Dart console application prompts the user to enter their name, surname, and year of birth. It calculates the user's age based on the current year and prints a personalized message with the calculated age.

### How to Run

1. Make sure you have Dart installed on your system.
2. Open a terminal or command prompt.
3. Navigate to the directory containing the Dart file.
4. Run the program using the command: `dart filename.dart`
5. Follow the prompts to enter your information.

## 3. Positive/Negative/Zero Checker

### Description

This Dart console application prompts the user to enter a number. It checks whether the entered number is positive, negative, or zero, and prints the corresponding message.

### How to Run

1. Make sure you have Dart installed on your system.
2. Open a terminal or command prompt.
3. Navigate to the directory containing the Dart file.
4. Run the program using the command: `dart filename.dart`
5. Follow the prompts to enter a number.
